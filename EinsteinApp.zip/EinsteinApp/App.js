import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { StatusBar } from 'expo-status-bar';

// Import screens
import HomeScreen from './screens/HomeScreen';
import BiographyScreen from './screens/BiographyScreen';
import AchievementsScreen from './screens/AchievementsScreen';
import WorksScreen from './screens/WorksScreen';
import GalleryScreen from './screens/GalleryScreen';

const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <StatusBar style="light" backgroundColor="#0f0f23" />
      <Stack.Navigator
        initialRouteName="Home"
        screenOptions={{
          headerShown: false,
          cardStyle: { backgroundColor: '#0f0f23' },
          cardStyleInterpolator: ({ current, layouts }) => {
            return {
              cardStyle: {
                transform: [
                  {
                    translateX: current.progress.interpolate({
                      inputRange: [0, 1],
                      outputRange: [layouts.screen.width, 0],
                    }),
                  },
                ],
              },
            };
          },
        }}
      >
        <Stack.Screen 
          name="Home" 
          component={HomeScreen}
          options={{
            title: 'Albert Einstein',
          }}
        />
        <Stack.Screen 
          name="Biography" 
          component={BiographyScreen}
          options={{
            title: 'Biografia',
          }}
        />
        <Stack.Screen 
          name="Achievements" 
          component={AchievementsScreen}
          options={{
            title: 'Realizações Científicas',
          }}
        />
        <Stack.Screen 
          name="Works" 
          component={WorksScreen}
          options={{
            title: 'Obras e Publicações',
          }}
        />
        <Stack.Screen 
          name="Gallery" 
          component={GalleryScreen}
          options={{
            title: 'Galeria',
          }}
        />
      </Stack.Navigator>
    </NavigationContainer>
  );
}

