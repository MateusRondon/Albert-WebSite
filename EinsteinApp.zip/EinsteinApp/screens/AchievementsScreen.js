import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function AchievementsScreen({ navigation }) {
  const achievements = [
    {
      id: 1,
      title: 'Teoria da Relatividade Especial',
      year: '1905',
      formula: 'E = mc²',
      description: 'Revolucionou nossa compreensão do espaço, tempo e energia. Estabeleceu que a velocidade da luz é constante e que massa e energia são intercambiáveis.',
      impact: 'Base para a física moderna e tecnologias como GPS.',
      color: '#e94560',
    },
    {
      id: 2,
      title: 'Efeito Fotoelétrico',
      year: '1905',
      formula: 'E = hf',
      description: 'Explicou como a luz pode ejetar elétrons de uma superfície metálica, provando a natureza quântica da luz.',
      impact: 'Fundamental para o desenvolvimento da mecânica quântica e tecnologias fotovoltaicas.',
      color: '#0f3460',
    },
    {
      id: 3,
      title: 'Teoria da Relatividade Geral',
      year: '1915',
      formula: 'Rμν - ½gμνR = 8πTμν',
      description: 'Descreveu a gravidade como curvatura do espaço-tempo, não como uma força.',
      impact: 'Previu buracos negros, ondas gravitacionais e expansão do universo.',
      color: '#16213e',
    },
    {
      id: 4,
      title: 'Movimento Browniano',
      year: '1905',
      formula: '⟨x²⟩ = 2Dt',
      description: 'Explicou o movimento aleatório de partículas suspensas em fluidos, provando a existência de átomos.',
      impact: 'Confirmou a teoria atômica da matéria.',
      color: '#1a1a2e',
    },
  ];

  const renderAchievement = (achievement) => (
    <View key={achievement.id} style={[styles.achievementCard, { borderLeftColor: achievement.color }]}>
      <View style={styles.cardHeader}>
        <Text style={styles.achievementTitle}>{achievement.title}</Text>
        <Text style={[styles.achievementYear, { color: achievement.color }]}>{achievement.year}</Text>
      </View>
      
      <View style={styles.formulaContainer}>
        <Text style={styles.formulaLabel}>Fórmula:</Text>
        <Text style={[styles.formula, { color: achievement.color }]}>{achievement.formula}</Text>
      </View>
      
      <Text style={styles.description}>{achievement.description}</Text>
      
      <View style={styles.impactContainer}>
        <Text style={styles.impactLabel}>Impacto:</Text>
        <Text style={styles.impact}>{achievement.impact}</Text>
      </View>
    </View>
  );

  return (
    <LinearGradient
      colors={['#0f0f23', '#1a1a2e', '#16213e']}
      style={styles.container}
    >
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Realizações Científicas</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.introSection}>
          <Text style={styles.introText}>
            Einstein revolucionou a física com descobertas que mudaram nossa compreensão 
            fundamental do universo. Suas teorias continuam sendo a base da ciência moderna.
          </Text>
        </View>

        <View style={styles.achievementsSection}>
          {achievements.map(renderAchievement)}
        </View>

        <View style={styles.nobelSection}>
          <Text style={styles.sectionTitle}>Prêmio Nobel de Física (1921)</Text>
          <View style={styles.nobelCard}>
            <Text style={styles.nobelText}>
              Einstein recebeu o Prêmio Nobel "por seus serviços à Física Teórica, 
              e especialmente pela descoberta da lei do efeito fotoelétrico".
            </Text>
            <Text style={styles.nobelNote}>
              Curiosamente, não foi pela Teoria da Relatividade, que ainda era 
              considerada controversa na época.
            </Text>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  backButtonText: {
    fontSize: 24,
    color: '#ffffff',
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  introSection: {
    marginBottom: 30,
  },
  introText: {
    fontSize: 16,
    color: '#b8b8b8',
    lineHeight: 24,
    textAlign: 'center',
  },
  achievementsSection: {
    marginBottom: 30,
  },
  achievementCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
    borderLeftWidth: 4,
  },
  cardHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 15,
  },
  achievementTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    flex: 1,
    marginRight: 10,
  },
  achievementYear: {
    fontSize: 16,
    fontWeight: 'bold',
  },
  formulaContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 15,
  },
  formulaLabel: {
    fontSize: 14,
    color: '#b8b8b8',
    marginRight: 10,
  },
  formula: {
    fontSize: 18,
    fontWeight: 'bold',
    fontFamily: 'monospace',
  },
  description: {
    fontSize: 16,
    color: '#b8b8b8',
    lineHeight: 22,
    marginBottom: 15,
    textAlign: 'justify',
  },
  impactContainer: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 8,
    padding: 12,
  },
  impactLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#e94560',
    marginBottom: 5,
  },
  impact: {
    fontSize: 14,
    color: '#b8b8b8',
    lineHeight: 20,
  },
  nobelSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
    textAlign: 'center',
  },
  nobelCard: {
    backgroundColor: 'rgba(233, 69, 96, 0.1)',
    borderRadius: 12,
    padding: 20,
    borderWidth: 1,
    borderColor: 'rgba(233, 69, 96, 0.3)',
  },
  nobelText: {
    fontSize: 16,
    color: '#ffffff',
    lineHeight: 24,
    marginBottom: 15,
    textAlign: 'center',
  },
  nobelNote: {
    fontSize: 14,
    color: '#b8b8b8',
    lineHeight: 20,
    fontStyle: 'italic',
    textAlign: 'center',
  },
});

