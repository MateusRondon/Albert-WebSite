// Smooth scrolling para links de navegação
document.addEventListener('DOMContentLoaded', function() {
    // Navegação suave
    const navLinks = document.querySelectorAll('.nav-link');
    
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetSection = document.querySelector(targetId);
            
            if (targetSection) {
                targetSection.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Animação de fade-in ao fazer scroll
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };

    const observer = new IntersectionObserver(function(entries) {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('visible');
            }
        });
    }, observerOptions);

    // Adicionar classe fade-in aos elementos que devem animar
    const animatedElements = document.querySelectorAll('.achievement-card, .timeline-item, .bio-content, .legacy-content');
    
    animatedElements.forEach(el => {
        el.classList.add('fade-in');
        observer.observe(el);
    });

    // Efeito parallax sutil no hero
    window.addEventListener('scroll', function() {
        const scrolled = window.pageYOffset;
        const hero = document.querySelector('.hero');
        const heroContent = document.querySelector('.hero-content');
        
        if (hero && scrolled < hero.offsetHeight) {
            heroContent.style.transform = `translateY(${scrolled * 0.5}px)`;
        }
    });

    // Destacar link ativo na navegação
    window.addEventListener('scroll', function() {
        const sections = document.querySelectorAll('.section');
        const navLinks = document.querySelectorAll('.nav-link');
        
        let current = '';
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.clientHeight;
            
            if (window.pageYOffset >= sectionTop - 200) {
                current = section.getAttribute('id');
            }
        });
        
        navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${current}`) {
                link.classList.add('active');
            }
        });
    });

    // Animação de digitação para a equação E=mc²
    const equation = document.querySelector('.hero-equation');
    if (equation) {
        const text = equation.textContent;
        equation.textContent = '';
        
        setTimeout(() => {
            let i = 0;
            const typeWriter = () => {
                if (i < text.length) {
                    equation.textContent += text.charAt(i);
                    i++;
                    setTimeout(typeWriter, 200);
                }
            };
            typeWriter();
        }, 1500);
    }

    // Efeito hover nas imagens
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.addEventListener('mouseenter', function() {
            this.style.filter = 'brightness(1.1) contrast(1.1)';
        });
        
        img.addEventListener('mouseleave', function() {
            this.style.filter = 'brightness(1) contrast(1)';
        });
    });

    // Contador animado para o ano de nascimento/morte
    const animateNumbers = () => {
        const timelineYears = document.querySelectorAll('.timeline-year');
        
        timelineYears.forEach(year => {
            const targetYear = parseInt(year.textContent);
            if (targetYear && targetYear > 1800) {
                let currentYear = 1879;
                const increment = (targetYear - currentYear) / 50;
                
                const updateYear = () => {
                    if (currentYear < targetYear) {
                        currentYear += increment;
                        year.textContent = Math.floor(currentYear);
                        requestAnimationFrame(updateYear);
                    } else {
                        year.textContent = targetYear;
                    }
                };
                
                // Iniciar animação quando o elemento estiver visível
                const yearObserver = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            updateYear();
                            yearObserver.unobserve(entry.target);
                        }
                    });
                });
                
                yearObserver.observe(year);
            }
        });
    };

    // Inicializar contador animado
    animateNumbers();

    // Easter egg: clique triplo na equação E=mc²
    let clickCount = 0;
    equation?.addEventListener('click', function() {
        clickCount++;
        if (clickCount === 3) {
            this.style.animation = 'none';
            this.style.transform = 'scale(1.2) rotate(360deg)';
            this.style.transition = 'all 1s ease';
            
            setTimeout(() => {
                this.style.transform = 'scale(1) rotate(0deg)';
                clickCount = 0;
            }, 1000);
        }
        
        setTimeout(() => {
            if (clickCount < 3) clickCount = 0;
        }, 1000);
    });
});

// Adicionar CSS para link ativo
const style = document.createElement('style');
style.textContent = `
    .nav-link.active {
        background: linear-gradient(135deg, #e94560 0%, #f27121 100%);
        color: white !important;
    }
    
    .nav-link.active::before {
        left: 0;
    }
`;
document.head.appendChild(style);

