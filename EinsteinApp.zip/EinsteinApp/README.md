# Aplicativo Albert Einstein

Um aplicativo móvel educacional sobre Albert Einstein, desenvolvido com React Native e Expo.

## 📱 Sobre o Aplicativo

Este aplicativo oferece uma experiência interativa e educativa sobre a vida e obra de Albert Einstein, incluindo:

- **Biografia**: Timeline detalhada da vida de Einstein
- **Realizações Científicas**: Principais descobertas e teorias
- **Obras e Publicações**: Trabalhos mais importantes
- **Galeria**: Fotos históricas e documentos

## 🎨 Design

- Interface moderna com gradientes escuros
- Paleta de cores inspirada no universo e física
- Design responsivo para dispositivos móveis
- Navegação intuitiva entre seções
- Animações suaves e transições elegantes

## 🚀 Como Executar

### Pré-requisitos

- Node.js (versão 18 ou superior)
- npm ou yarn
- Expo CLI

### Instalação

1. Clone ou extraia o projeto
2. Navegue até o diretório do projeto:
   ```bash
   cd EinsteinApp
   ```

3. Instale as dependências:
   ```bash
   npm install
   ```

### Executar o Aplicativo

#### Web (Navegador)
```bash
npm run web
```
Acesse: http://localhost:8081

#### Android
```bash
npm run android
```
(Requer Android Studio e emulador configurado)

#### iOS
```bash
npm run ios
```
(Requer macOS e Xcode)

#### Expo Go (Dispositivo Físico)
```bash
npx expo start
```
Escaneie o QR code com o app Expo Go

## 📦 Estrutura do Projeto

```
EinsteinApp/
├── App.js                 # Componente principal com navegação
├── screens/               # Telas do aplicativo
│   ├── HomeScreen.js      # Tela inicial
│   ├── BiographyScreen.js # Biografia de Einstein
│   ├── AchievementsScreen.js # Realizações científicas
│   ├── WorksScreen.js     # Obras e publicações
│   └── GalleryScreen.js   # Galeria de fotos
├── assets/                # Recursos (imagens, ícones)
├── package.json           # Dependências do projeto
└── README.md             # Este arquivo
```

## 🛠️ Tecnologias Utilizadas

- **React Native**: Framework para desenvolvimento mobile
- **Expo**: Plataforma para desenvolvimento React Native
- **React Navigation**: Navegação entre telas
- **Expo Linear Gradient**: Gradientes visuais
- **React Native Screens**: Otimização de performance

## 📱 Funcionalidades

### Tela Inicial
- Foto icônica de Einstein
- Menu principal com cards navegáveis
- Fatos rápidos sobre Einstein

### Biografia
- Timeline interativa com eventos importantes
- Informações sobre personalidade
- Design visual atrativo

### Realizações Científicas
- Teoria da Relatividade Especial e Geral
- Efeito Fotoelétrico
- Movimento Browniano
- Fórmulas e explicações detalhadas

### Obras e Publicações
- Lista de trabalhos importantes
- Categorização por tipo (artigos, livros, ensaios)
- Estatísticas de publicações

### Galeria
- Fotos históricas organizadas por categoria
- Filtros por tipo de conteúdo
- Descrições contextuais

## 🎯 Público-Alvo

- Estudantes de física e ciências
- Entusiastas da ciência
- Educadores
- Público geral interessado em Einstein

## 📄 Licença

Este projeto é educacional e utiliza conteúdo de domínio público sobre Albert Einstein.

## 👨‍💻 Desenvolvimento

Desenvolvido como um aplicativo educacional moderno, focando em:
- Experiência do usuário intuitiva
- Design visual atrativo
- Conteúdo educativo de qualidade
- Performance otimizada
- Compatibilidade multiplataforma

---

**"A imaginação é mais importante que o conhecimento"** - Albert Einstein

