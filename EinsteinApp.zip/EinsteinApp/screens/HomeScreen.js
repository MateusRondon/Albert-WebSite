import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
  Image,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const { width, height } = Dimensions.get('window');

export default function HomeScreen({ navigation }) {
  const menuItems = [
    {
      id: 1,
      title: 'Biografia',
      subtitle: 'Vida e trajetória',
      icon: '👤',
      screen: 'Biography',
      color: '#e94560',
    },
    {
      id: 2,
      title: 'Realizações',
      subtitle: 'Descobertas científicas',
      icon: '🔬',
      screen: 'Achievements',
      color: '#0f3460',
    },
    {
      id: 3,
      title: 'Obras',
      subtitle: 'Publicações importantes',
      icon: '📚',
      screen: 'Works',
      color: '#16213e',
    },
    {
      id: 4,
      title: 'Galeria',
      subtitle: 'Fotos e documentos',
      icon: '🖼️',
      screen: 'Gallery',
      color: '#1a1a2e',
    },
  ];

  const renderMenuItem = (item) => (
    <TouchableOpacity
      key={item.id}
      style={[styles.menuCard, { borderLeftColor: item.color }]}
      onPress={() => navigation.navigate(item.screen)}
      activeOpacity={0.8}
    >
      <View style={styles.cardContent}>
        <Text style={styles.cardIcon}>{item.icon}</Text>
        <View style={styles.cardText}>
          <Text style={styles.cardTitle}>{item.title}</Text>
          <Text style={styles.cardSubtitle}>{item.subtitle}</Text>
        </View>
        <Text style={styles.cardArrow}>›</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <LinearGradient
      colors={['#0f0f23', '#1a1a2e', '#16213e']}
      style={styles.container}
    >
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header Section */}
        <View style={styles.header}>
          <View style={styles.imageContainer}>
            <Image
              source={{
                uri: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Einstein_1921_by_F_Schmutzer_-_restoration.jpg/256px-Einstein_1921_by_F_Schmutzer_-_restoration.jpg'
              }}
              style={styles.einsteinImage}
              resizeMode="cover"
            />
            <LinearGradient
              colors={['transparent', 'rgba(15, 15, 35, 0.8)']}
              style={styles.imageOverlay}
            />
          </View>
          <Text style={styles.mainTitle}>Albert Einstein</Text>
          <Text style={styles.subtitle}>
            "A imaginação é mais importante que o conhecimento"
          </Text>
        </View>

        {/* Menu Section */}
        <View style={styles.menuSection}>
          <Text style={styles.sectionTitle}>Explore</Text>
          {menuItems.map(renderMenuItem)}
        </View>

        {/* Quick Facts */}
        <View style={styles.factsSection}>
          <Text style={styles.sectionTitle}>Fatos Rápidos</Text>
          <View style={styles.factCard}>
            <Text style={styles.factText}>
              <Text style={styles.factLabel}>Nascimento:</Text> 14 de março de 1879
            </Text>
            <Text style={styles.factText}>
              <Text style={styles.factLabel}>Nobel:</Text> Física (1921)
            </Text>
            <Text style={styles.factText}>
              <Text style={styles.factLabel}>Famoso por:</Text> Teoria da Relatividade
            </Text>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  scrollContent: {
    paddingBottom: 30,
  },
  header: {
    alignItems: 'center',
    paddingTop: 60,
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  imageContainer: {
    width: 150,
    height: 150,
    borderRadius: 75,
    overflow: 'hidden',
    marginBottom: 20,
    elevation: 10,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 5 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
  },
  einsteinImage: {
    width: '100%',
    height: '100%',
  },
  imageOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 50,
  },
  mainTitle: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 16,
    color: '#b8b8b8',
    textAlign: 'center',
    fontStyle: 'italic',
    paddingHorizontal: 20,
  },
  menuSection: {
    paddingHorizontal: 20,
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 20,
  },
  menuCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    marginBottom: 15,
    borderLeftWidth: 4,
    overflow: 'hidden',
  },
  cardContent: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 20,
  },
  cardIcon: {
    fontSize: 24,
    marginRight: 15,
  },
  cardText: {
    flex: 1,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 4,
  },
  cardSubtitle: {
    fontSize: 14,
    color: '#b8b8b8',
  },
  cardArrow: {
    fontSize: 24,
    color: '#b8b8b8',
    fontWeight: 'bold',
  },
  factsSection: {
    paddingHorizontal: 20,
  },
  factCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
  },
  factText: {
    fontSize: 16,
    color: '#ffffff',
    marginBottom: 8,
  },
  factLabel: {
    fontWeight: 'bold',
    color: '#e94560',
  },
});

