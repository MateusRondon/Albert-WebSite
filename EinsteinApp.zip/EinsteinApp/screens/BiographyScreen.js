import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function BiographyScreen({ navigation }) {
  const timelineEvents = [
    {
      year: '1879',
      title: 'Nascimento',
      description: 'Nasce em Ulm, Alemanha, em 14 de março.',
    },
    {
      year: '1896',
      title: 'Estudos',
      description: 'Ingressa na Escola Politécnica Federal de Zurique.',
    },
    {
      year: '1905',
      title: 'Ano Miraculoso',
      description: 'Publica cinco artigos revolucionários, incluindo a Teoria da Relatividade Especial.',
    },
    {
      year: '1915',
      title: 'Relatividade Geral',
      description: 'Completa a Teoria da Relatividade Geral.',
    },
    {
      year: '1921',
      title: 'Prêmio Nobel',
      description: 'Recebe o Nobel de Física pelo efeito fotoelétrico.',
    },
    {
      year: '1933',
      title: 'Emigração',
      description: 'Muda-se para os Estados Unidos devido ao nazismo.',
    },
    {
      year: '1955',
      title: 'Falecimento',
      description: 'Morre em Princeton, Nova Jersey, em 18 de abril.',
    },
  ];

  const renderTimelineEvent = (event, index) => (
    <View key={index} style={styles.timelineItem}>
      <View style={styles.timelineMarker}>
        <View style={styles.timelineDot} />
        {index < timelineEvents.length - 1 && <View style={styles.timelineLine} />}
      </View>
      <View style={styles.timelineContent}>
        <Text style={styles.timelineYear}>{event.year}</Text>
        <Text style={styles.timelineTitle}>{event.title}</Text>
        <Text style={styles.timelineDescription}>{event.description}</Text>
      </View>
    </View>
  );

  return (
    <LinearGradient
      colors={['#0f0f23', '#1a1a2e', '#16213e']}
      style={styles.container}
    >
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Biografia</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.introSection}>
          <Text style={styles.introTitle}>Albert Einstein</Text>
          <Text style={styles.introSubtitle}>1879 - 1955</Text>
          <Text style={styles.introText}>
            Albert Einstein foi um físico teórico alemão que desenvolveu a teoria da relatividade, 
            uma das duas bases da física moderna (ao lado da mecânica quântica). Seu trabalho 
            também é conhecido por sua influência na filosofia da ciência.
          </Text>
        </View>

        <View style={styles.timelineSection}>
          <Text style={styles.sectionTitle}>Linha do Tempo</Text>
          {timelineEvents.map(renderTimelineEvent)}
        </View>

        <View style={styles.personalitySection}>
          <Text style={styles.sectionTitle}>Personalidade</Text>
          <View style={styles.personalityCard}>
            <Text style={styles.personalityText}>
              Einstein era conhecido por sua curiosidade insaciável, senso de humor peculiar 
              e profunda preocupação com questões sociais e políticas. Ele era um pacifista 
              convicto e defensor dos direitos civis.
            </Text>
            <Text style={styles.personalityText}>
              Sua aparência desalinhada e cabelos despenteados se tornaram icônicos, 
              simbolizando o estereótipo do "cientista maluco" genial.
            </Text>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  backButtonText: {
    fontSize: 24,
    color: '#ffffff',
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  introSection: {
    marginBottom: 30,
  },
  introTitle: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 5,
  },
  introSubtitle: {
    fontSize: 16,
    color: '#e94560',
    textAlign: 'center',
    marginBottom: 20,
    fontWeight: 'bold',
  },
  introText: {
    fontSize: 16,
    color: '#b8b8b8',
    lineHeight: 24,
    textAlign: 'justify',
  },
  timelineSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 20,
  },
  timelineItem: {
    flexDirection: 'row',
    marginBottom: 20,
  },
  timelineMarker: {
    alignItems: 'center',
    marginRight: 15,
  },
  timelineDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: '#e94560',
  },
  timelineLine: {
    width: 2,
    flex: 1,
    backgroundColor: 'rgba(233, 69, 96, 0.3)',
    marginTop: 5,
  },
  timelineContent: {
    flex: 1,
    paddingBottom: 10,
  },
  timelineYear: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#e94560',
    marginBottom: 5,
  },
  timelineTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 5,
  },
  timelineDescription: {
    fontSize: 14,
    color: '#b8b8b8',
    lineHeight: 20,
  },
  personalitySection: {
    marginBottom: 30,
  },
  personalityCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
  },
  personalityText: {
    fontSize: 16,
    color: '#b8b8b8',
    lineHeight: 24,
    marginBottom: 15,
    textAlign: 'justify',
  },
});

