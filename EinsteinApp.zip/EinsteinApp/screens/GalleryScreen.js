import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
  Image,
  Dimensions,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

const { width } = Dimensions.get('window');

export default function GalleryScreen({ navigation }) {
  const galleryItems = [
    {
      id: 1,
      title: 'Einstein Jovem (1904)',
      description: 'Einstein aos 25 anos, quando trabalhava no escritório de patentes em Berna.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f5/Einstein_1904.jpg/256px-Einstein_1904.jpg',
      category: 'Fotos Pessoais',
    },
    {
      id: 2,
      title: 'Conferência de Solvay (1927)',
      description: 'Einstein com outros grandes físicos na famosa conferência sobre mecânica quântica.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/6e/Solvay_conference_1927.jpg/512px-Solvay_conference_1927.jpg',
      category: 'Eventos Científicos',
    },
    {
      id: 3,
      title: 'Einstein em Princeton (1940)',
      description: 'Einstein em seu escritório no Instituto de Estudos Avançados de Princeton.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/5/50/Albert_Einstein_%28Nobel%29.png/256px-Albert_Einstein_%28Nobel%29.png',
      category: 'Vida Acadêmica',
    },
    {
      id: 4,
      title: 'Manuscrito E=mc²',
      description: 'Página original do manuscrito onde Einstein derivou sua famosa equação.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/c/ce/Einstein_manuscript.jpg/256px-Einstein_manuscript.jpg',
      category: 'Documentos',
    },
    {
      id: 5,
      title: 'Einstein e Charlie Chaplin (1931)',
      description: 'Einstein com Charlie Chaplin na estreia de "Luzes da Cidade" em Hollywood.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/1/14/Einstein_and_Chaplin_1931.jpg/256px-Einstein_and_Chaplin_1931.jpg',
      category: 'Vida Social',
    },
    {
      id: 6,
      title: 'Última Foto (1955)',
      description: 'Uma das últimas fotografias de Einstein, tirada pouco antes de sua morte.',
      image: 'https://upload.wikimedia.org/wikipedia/commons/thumb/3/3e/Einstein_1921_by_F_Schmutzer_-_restoration.jpg/256px-Einstein_1921_by_F_Schmutzer_-_restoration.jpg',
      category: 'Fotos Pessoais',
    },
  ];

  const categories = ['Todas', 'Fotos Pessoais', 'Eventos Científicos', 'Vida Acadêmica', 'Documentos', 'Vida Social'];
  const [selectedCategory, setSelectedCategory] = React.useState('Todas');

  const filteredItems = selectedCategory === 'Todas' 
    ? galleryItems 
    : galleryItems.filter(item => item.category === selectedCategory);

  const getCategoryColor = (category) => {
    const colors = {
      'Fotos Pessoais': '#e94560',
      'Eventos Científicos': '#0f3460',
      'Vida Acadêmica': '#16213e',
      'Documentos': '#1a1a2e',
      'Vida Social': '#2d1b69',
    };
    return colors[category] || '#b8b8b8';
  };

  const renderCategoryFilter = (category) => (
    <TouchableOpacity
      key={category}
      style={[
        styles.categoryButton,
        selectedCategory === category && styles.categoryButtonActive
      ]}
      onPress={() => setSelectedCategory(category)}
    >
      <Text style={[
        styles.categoryButtonText,
        selectedCategory === category && styles.categoryButtonTextActive
      ]}>
        {category}
      </Text>
    </TouchableOpacity>
  );

  const renderGalleryItem = (item) => (
    <View key={item.id} style={styles.galleryItem}>
      <View style={styles.imageContainer}>
        <Image
          source={{ uri: item.image }}
          style={styles.galleryImage}
          resizeMode="cover"
        />
        <LinearGradient
          colors={['transparent', 'rgba(0, 0, 0, 0.7)']}
          style={styles.imageOverlay}
        />
        <View style={[styles.categoryTag, { backgroundColor: getCategoryColor(item.category) }]}>
          <Text style={styles.categoryTagText}>{item.category}</Text>
        </View>
      </View>
      <View style={styles.itemContent}>
        <Text style={styles.itemTitle}>{item.title}</Text>
        <Text style={styles.itemDescription}>{item.description}</Text>
      </View>
    </View>
  );

  return (
    <LinearGradient
      colors={['#0f0f23', '#1a1a2e', '#16213e']}
      style={styles.container}
    >
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Galeria</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.introSection}>
          <Text style={styles.introText}>
            Uma coleção de fotografias históricas e documentos que retratam a vida 
            e obra de Albert Einstein ao longo dos anos.
          </Text>
        </View>

        <View style={styles.filterSection}>
          <Text style={styles.filterTitle}>Categorias</Text>
          <ScrollView 
            horizontal 
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.categoryContainer}
          >
            {categories.map(renderCategoryFilter)}
          </ScrollView>
        </View>

        <View style={styles.gallerySection}>
          <Text style={styles.sectionTitle}>
            {selectedCategory === 'Todas' ? 'Todas as Imagens' : selectedCategory}
            <Text style={styles.itemCount}> ({filteredItems.length})</Text>
          </Text>
          {filteredItems.map(renderGalleryItem)}
        </View>

        <View style={styles.noteSection}>
          <View style={styles.noteCard}>
            <Text style={styles.noteTitle}>Nota Histórica</Text>
            <Text style={styles.noteText}>
              Estas imagens são parte do arquivo histórico público e documentam 
              momentos importantes da vida de Einstein, desde seus primeiros anos 
              como cientista até seus últimos dias em Princeton.
            </Text>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  backButtonText: {
    fontSize: 24,
    color: '#ffffff',
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  introSection: {
    marginBottom: 30,
  },
  introText: {
    fontSize: 16,
    color: '#b8b8b8',
    lineHeight: 24,
    textAlign: 'center',
  },
  filterSection: {
    marginBottom: 30,
  },
  filterTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 15,
  },
  categoryContainer: {
    paddingRight: 20,
  },
  categoryButton: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 10,
  },
  categoryButtonActive: {
    backgroundColor: '#e94560',
  },
  categoryButtonText: {
    fontSize: 14,
    color: '#b8b8b8',
    fontWeight: '500',
  },
  categoryButtonTextActive: {
    color: '#ffffff',
    fontWeight: 'bold',
  },
  gallerySection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 20,
  },
  itemCount: {
    fontSize: 16,
    color: '#e94560',
    fontWeight: 'normal',
  },
  galleryItem: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    marginBottom: 20,
    overflow: 'hidden',
  },
  imageContainer: {
    position: 'relative',
    height: 200,
  },
  galleryImage: {
    width: '100%',
    height: '100%',
  },
  imageOverlay: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    height: 60,
  },
  categoryTag: {
    position: 'absolute',
    top: 10,
    right: 10,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 12,
  },
  categoryTagText: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: 'bold',
  },
  itemContent: {
    padding: 20,
  },
  itemTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 8,
  },
  itemDescription: {
    fontSize: 16,
    color: '#b8b8b8',
    lineHeight: 22,
  },
  noteSection: {
    marginBottom: 30,
  },
  noteCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    borderLeftWidth: 4,
    borderLeftColor: '#e94560',
  },
  noteTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#e94560',
    marginBottom: 10,
  },
  noteText: {
    fontSize: 14,
    color: '#b8b8b8',
    lineHeight: 20,
  },
});

