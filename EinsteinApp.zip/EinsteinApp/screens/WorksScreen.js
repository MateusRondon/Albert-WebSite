import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  TouchableOpacity,
} from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';

export default function WorksScreen({ navigation }) {
  const works = [
    {
      id: 1,
      title: 'Sobre a Eletrodinâmica dos Corpos em Movimento',
      year: '1905',
      type: 'Artigo Científico',
      description: 'O artigo que introduziu a Teoria da Relatividade Especial, revolucionando nossa compreensão do espaço e tempo.',
      significance: 'Estabeleceu os fundamentos da física moderna',
      pages: '30 páginas',
    },
    {
      id: 2,
      title: 'Sobre um Ponto de Vista Heurístico Concernente à Produção e Transformação da Luz',
      year: '1905',
      type: 'Artigo Científico',
      description: 'Explicação do efeito fotoelétrico que lhe rendeu o Prêmio Nobel de Física.',
      significance: 'Provou a natureza quântica da luz',
      pages: '9 páginas',
    },
    {
      id: 3,
      title: 'Os Fundamentos da Teoria da Relatividade Geral',
      year: '1916',
      type: 'Artigo Científico',
      description: 'Apresentação completa da Teoria da Relatividade Geral, descrevendo a gravidade como curvatura do espaço-tempo.',
      significance: 'Revolucionou nossa compreensão da gravidade',
      pages: '64 páginas',
    },
    {
      id: 4,
      title: 'A Evolução da Física',
      year: '1938',
      type: 'Livro',
      description: 'Escrito com Leopold Infeld, explica o desenvolvimento da física de Newton à mecânica quântica.',
      significance: 'Divulgação científica acessível ao público geral',
      pages: '319 páginas',
    },
    {
      id: 5,
      title: 'Por que o Socialismo?',
      year: '1949',
      type: 'Ensaio',
      description: 'Artigo político onde Einstein defende o socialismo democrático como solução para problemas sociais.',
      significance: 'Mostra o engajamento político de Einstein',
      pages: '8 páginas',
    },
    {
      id: 6,
      title: 'Autobiographical Notes',
      year: '1949',
      type: 'Autobiografia',
      description: 'Reflexões pessoais sobre sua vida, trabalho científico e filosofia.',
      significance: 'Única autobiografia oficial de Einstein',
      pages: '95 páginas',
    },
  ];

  const getTypeColor = (type) => {
    switch (type) {
      case 'Artigo Científico': return '#e94560';
      case 'Livro': return '#0f3460';
      case 'Ensaio': return '#16213e';
      case 'Autobiografia': return '#1a1a2e';
      default: return '#b8b8b8';
    }
  };

  const renderWork = (work) => (
    <View key={work.id} style={styles.workCard}>
      <View style={styles.workHeader}>
        <View style={[styles.typeTag, { backgroundColor: getTypeColor(work.type) }]}>
          <Text style={styles.typeText}>{work.type}</Text>
        </View>
        <Text style={styles.workYear}>{work.year}</Text>
      </View>
      
      <Text style={styles.workTitle}>{work.title}</Text>
      
      <Text style={styles.workDescription}>{work.description}</Text>
      
      <View style={styles.workDetails}>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Significado:</Text>
          <Text style={styles.detailValue}>{work.significance}</Text>
        </View>
        <View style={styles.detailRow}>
          <Text style={styles.detailLabel}>Extensão:</Text>
          <Text style={styles.detailValue}>{work.pages}</Text>
        </View>
      </View>
    </View>
  );

  return (
    <LinearGradient
      colors={['#0f0f23', '#1a1a2e', '#16213e']}
      style={styles.container}
    >
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.backButton}
          onPress={() => navigation.goBack()}
        >
          <Text style={styles.backButtonText}>‹</Text>
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Obras e Publicações</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        <View style={styles.introSection}>
          <Text style={styles.introText}>
            Einstein publicou mais de 300 artigos científicos e 150 trabalhos não-científicos. 
            Aqui estão suas obras mais influentes que moldaram a ciência moderna.
          </Text>
        </View>

        <View style={styles.statsSection}>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>300+</Text>
            <Text style={styles.statLabel}>Artigos Científicos</Text>
          </View>
          <View style={styles.statCard}>
            <Text style={styles.statNumber}>150+</Text>
            <Text style={styles.statLabel}>Trabalhos Não-Científicos</Text>
          </View>
        </View>

        <View style={styles.worksSection}>
          <Text style={styles.sectionTitle}>Principais Obras</Text>
          {works.map(renderWork)}
        </View>

        <View style={styles.legacySection}>
          <Text style={styles.sectionTitle}>Legado Literário</Text>
          <View style={styles.legacyCard}>
            <Text style={styles.legacyText}>
              Além de suas contribuições científicas, Einstein foi um prolífico escritor 
              sobre filosofia, política e questões sociais. Suas cartas e ensaios revelam 
              um pensador profundamente humanista.
            </Text>
            <Text style={styles.legacyQuote}>
              "Uma pessoa que nunca cometeu um erro nunca tentou nada novo."
            </Text>
          </View>
        </View>
      </ScrollView>
    </LinearGradient>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 50,
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 15,
  },
  backButtonText: {
    fontSize: 24,
    color: '#ffffff',
    fontWeight: 'bold',
  },
  headerTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: '#ffffff',
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 30,
  },
  introSection: {
    marginBottom: 30,
  },
  introText: {
    fontSize: 16,
    color: '#b8b8b8',
    lineHeight: 24,
    textAlign: 'center',
  },
  statsSection: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 30,
  },
  statCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    alignItems: 'center',
    flex: 0.48,
  },
  statNumber: {
    fontSize: 32,
    fontWeight: 'bold',
    color: '#e94560',
    marginBottom: 5,
  },
  statLabel: {
    fontSize: 14,
    color: '#b8b8b8',
    textAlign: 'center',
  },
  worksSection: {
    marginBottom: 30,
  },
  sectionTitle: {
    fontSize: 22,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 20,
  },
  workCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
    marginBottom: 20,
  },
  workHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 15,
  },
  typeTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 20,
  },
  typeText: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: 'bold',
  },
  workYear: {
    fontSize: 16,
    color: '#e94560',
    fontWeight: 'bold',
  },
  workTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 10,
    lineHeight: 24,
  },
  workDescription: {
    fontSize: 16,
    color: '#b8b8b8',
    lineHeight: 22,
    marginBottom: 15,
    textAlign: 'justify',
  },
  workDetails: {
    backgroundColor: 'rgba(255, 255, 255, 0.05)',
    borderRadius: 8,
    padding: 12,
  },
  detailRow: {
    flexDirection: 'row',
    marginBottom: 5,
  },
  detailLabel: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#e94560',
    width: 80,
  },
  detailValue: {
    fontSize: 14,
    color: '#b8b8b8',
    flex: 1,
  },
  legacySection: {
    marginBottom: 30,
  },
  legacyCard: {
    backgroundColor: 'rgba(255, 255, 255, 0.1)',
    borderRadius: 12,
    padding: 20,
  },
  legacyText: {
    fontSize: 16,
    color: '#b8b8b8',
    lineHeight: 24,
    marginBottom: 15,
    textAlign: 'justify',
  },
  legacyQuote: {
    fontSize: 16,
    color: '#e94560',
    fontStyle: 'italic',
    textAlign: 'center',
    lineHeight: 24,
  },
});

